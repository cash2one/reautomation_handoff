CONFIG_CHANGE_WAIT_TIME = 100
CONNECTION_WAIT_TIME = 10


# class IAP_1:
	# '''
	# Device under test details .
	# '''
	# consoleIp = "10.29.2.56"
	# consoleUsername = "console"
	# consolePassword = "console"
	# ip = "10.29.27.122"
	# username = "admin"
	# password = "test123"
	# type = "IAP"
	# version = '4.1.1.6'
	# server = "jenkins-metis-athena-build-nae-14.test.pdt1.arubathena.com"
	# protocol = "ssh"
	# port = "7008"
	# ap_type = "IAP-204-RW"
	# mac = "94:b4:0f:cc:ec:5a"
	# mac_address = "94:b4:0f:cc:ec:5a"
	# gatewayip= "10.29.27.121"
	# netmask = "255.255.255.248"
	# gateway_ip= "10.29.27.121"
	# dns_ip= "8.8.8.8"
	# location = "India"
	# vc_name = 'instant-CC:EC:5A'
	# prompt = "#"
	# serial_no = 'CM0235392'
	# activation_id = 'HIEGCTRD' 
	
class IAP_1:
	'''
	Device under test details .
	'''
	consoleIp = "10.15.140.8"
	consoleUsername = "root"
	consolePassword = "Aruba@123"
	ip = "10.15.141.38"
	username = "admin"
	password = "test123"
	type = "IAP"
	version = '4.1.1.6'
	server = "jenkins-metis-athena-build-nae-14.test.pdt1.arubathena.com"
	protocol = "ssh"
	port = "7010"
	ap_type = "RAP-109"
	mac = "24:de:c6:cb:1f:70"
	mac_address = "24:de:c6:cb:1f:70"
	gatewayip= "10.15.141.33"
	netmask = "255.255.255.248"
	gateway_ip= "10.15.141.33"
	dns_ip= "8.8.8.8"
	location = "India"
	vc_name = 'Instant-CB:1F:70'
	prompt = "#"
	serial_no = 'BV0024968'
	activation_id = 'PXILCCOI'  



# class Client_1:
	# ip = "10.29.27.21"
	# eth_ip = "10.29.254.20"
	# username = "athenatest"
	# password = "Test1234"
	# type = "CLIENT"
	# os = "Win8"
	# protocol = "ssh"
	# mac = "c4:d9:87:00:f5:32"
	# location = "Chennai"


# class Switch_1:
	# consoleIp = "10.15.148.253"
	# consoleUsername = "admin"
	# consolePassword = "aruba123"
	# ip = "10.15.148.38"
	# username = "admin"
	# password = "admin123"
	# enable = "enable"
	# type = "SWITCH"
	# version = 4.0
	# server = "54.179.64.28"
	# protocol = "telnet"
	# port = "7004"
	# prompt = ") #"
	# switch_name = "ArubaS2500"
	# location = "Bangalore, Karnataka, India"
	# mac = '00:0b:86:a4:3a:80'
	# serial = "BY0007437"
	# activation_id = 'WHB7HTO3'

